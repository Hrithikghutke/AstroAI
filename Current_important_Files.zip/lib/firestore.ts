import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  increment,
  serverTimestamp,
  collection,
  addDoc,
  query,
  where,
  orderBy,
  getDocs,
  deleteDoc,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { generateShareId } from "@/lib/generateId";

const STARTING_CREDITS = 50;

/* -------------------------------------------------------
   Create a new user document when they sign up.
   Called from the webhook in Step 10.
------------------------------------------------------- */
export async function createUserRecord(clerkUserId: string, email: string) {
  const userRef = doc(db, "users", clerkUserId);
  const existing = await getDoc(userRef);

  // Don't overwrite if they already exist
  if (existing.exists()) return;

  await setDoc(userRef, {
    clerkUserId,
    email,
    credits: STARTING_CREDITS,
    totalGenerated: 0,
    createdAt: serverTimestamp(),
    // Add these fields to your existing createUserRecord function
    // inside the setDoc call — add alongside existing fields:
    subscription: null, // null = no active subscription
    subscriptionId: null, // Razorpay subscription ID
    subscriptionPlan: null, // "starter" | "pro" | "agency"
    subscriptionStatus: null, // "active" | "cancelled" | "expired"
    subscriptionPeriod: null, // "monthly" | "annual"
    creditsRefreshDate: null, // next credits refresh date (timestamp)
  });
}

/* -------------------------------------------------------
   Get a user's current credit balance.
------------------------------------------------------- */
export async function getUserCredits(clerkUserId: string): Promise<number> {
  const userRef = doc(db, "users", clerkUserId);
  const snap = await getDoc(userRef);

  if (!snap.exists()) return 0;
  return snap.data().credits ?? 0;
}

/* -------------------------------------------------------
   Deduct 1 credit and increment totalGenerated.
   Returns false if the user doesn't have enough credits.
------------------------------------------------------- */
export async function deductCredit(clerkUserId: string): Promise<boolean> {
  return deductCredits(clerkUserId, 1);
}

export async function deductCredits(
  clerkUserId: string,
  amount: number,
): Promise<boolean> {
  const credits = await getUserCredits(clerkUserId);
  if (credits < amount) return false;

  const userRef = doc(db, "users", clerkUserId);
  await updateDoc(userRef, {
    credits: increment(-amount),
    totalGenerated: increment(1),
  });

  return true;
}

/* -------------------------------------------------------
   Save a generated website to Firestore.
   Returns the new document id and shareId.
------------------------------------------------------- */
export async function saveGeneration(
  clerkUserId: string,
  prompt: string,
  layout: any,
  deepHtml: string | null = null,
): Promise<{ id: string; shareId: string }> {
  const shareId = generateShareId();

  const docRef = await addDoc(collection(db, "generations"), {
    clerkUserId,
    prompt,
    layout: layout ?? null,
    deepHtml: deepHtml ?? null,
    mode: deepHtml ? "deep" : "fast",
    shareId,
    siteName: deepHtml
      ? extractTitleFromHtml(deepHtml)
      : (layout?.branding?.logoText ?? "Untitled"),
    themeStyle: layout?.themeStyle ?? "corporate",
    createdAt: serverTimestamp(),
  });

  return { id: docRef.id, shareId };
}

// Helper to extract <title> from deep dive HTML for siteName
function extractTitleFromHtml(html: string): string {
  const match = html.match(/<title>([^<]+)<\/title>/i);
  if (!match) return "Untitled";
  // Strip " - Tagline" suffix if present, just keep brand name
  return match[1].split(" - ")[0].split(" | ")[0].trim();
}

/* -------------------------------------------------------
   Get all saved sites for a user, newest first.
------------------------------------------------------- */
export async function getUserGenerations(clerkUserId: string) {
  const q = query(
    collection(db, "generations"),
    where("clerkUserId", "==", clerkUserId),
    orderBy("createdAt", "desc"),
  );

  const snap = await getDocs(q);

  return snap.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    // Convert Firestore timestamp to ISO string for JSON serialization
    createdAt: doc.data().createdAt?.toDate?.()?.toISOString() ?? null,
  }));
}

/* -------------------------------------------------------
   Get a single generation by shareId (public — no auth).
------------------------------------------------------- */
export async function getGenerationByShareId(shareId: string) {
  const q = query(
    collection(db, "generations"),
    where("shareId", "==", shareId),
  );

  const snap = await getDocs(q);
  if (snap.empty) return null;

  const doc = snap.docs[0];
  return {
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate?.()?.toISOString() ?? null,
  };
}

/* -------------------------------------------------------
   Delete a generation — only if it belongs to the user.
------------------------------------------------------- */
export async function deleteGeneration(
  docId: string,
  clerkUserId: string,
): Promise<void> {
  const ref = doc(db, "generations", docId);
  const snap = await getDoc(ref);

  if (!snap.exists()) throw new Error("Not found");
  if (snap.data().clerkUserId !== clerkUserId) throw new Error("Unauthorized");

  await deleteDoc(ref);
}

/* -------------------------------------------------------
  Update a generation with new layout and prompt — only if it belongs to the user.
------------------------------------------------------- */

export async function updateGeneration(
  docId: string,
  clerkUserId: string,
  layout: any,
  prompt: string,
  deepHtml: string | null = null,
): Promise<void> {
  const ref = doc(db, "generations", docId);
  const snap = await getDoc(ref);

  if (!snap.exists()) throw new Error("Not found");
  if (snap.data().clerkUserId !== clerkUserId) throw new Error("Unauthorized");

  await updateDoc(ref, {
    layout: layout ?? null,
    deepHtml: deepHtml ?? null,
    mode: deepHtml ? "deep" : "fast",
    prompt,
    siteName: deepHtml
      ? extractTitleFromHtml(deepHtml)
      : (layout?.branding?.logoText ?? "Untitled"),
    themeStyle: deepHtml ? "deep-dive" : (layout?.themeStyle ?? "corporate"),
    updatedAt: serverTimestamp(),
  });
}

// ── Save rating as training data ──
export async function rateGeneration(
  clerkUserId: string,
  rating: "positive" | "negative",
  prompt: string,
  html: string,
  model: string,
  feedback?: string[],
): Promise<string> {
  const docRef = await addDoc(collection(db, "ratings"), {
    clerkUserId,
    rating,
    prompt,
    html,
    model,
    feedback: feedback ?? [],
    createdAt: serverTimestamp(),
  });
  return docRef.id; // return doc ID for future updates
}

export async function updateRating(
  docId: string,
  rating: "positive" | "negative",
  feedback?: string[],
): Promise<void> {
  const ref = doc(db, "ratings", docId);
  await updateDoc(ref, {
    rating,
    feedback: feedback ?? [],
    updatedAt: serverTimestamp(),
  });
}

// ── Subscription helpers ──

export async function getUserSubscription(clerkUserId: string) {
  const userRef = doc(db, "users", clerkUserId);
  const snap = await getDoc(userRef);
  if (!snap.exists()) return null;
  const data = snap.data();
  return {
    subscription: data.subscription ?? null,
    subscriptionId: data.subscriptionId ?? null,
    subscriptionPlan: data.subscriptionPlan ?? null,
    subscriptionStatus: data.subscriptionStatus ?? null,
    subscriptionPeriod: data.subscriptionPeriod ?? null,
    creditsRefreshDate: data.creditsRefreshDate ?? null,
    subscriptionEndDate: data.subscriptionEndDate ?? null,
  };
}

export async function activateSubscription(
  clerkUserId: string,
  subscriptionId: string,
  plan: string,
  period: string,
  creditsToAdd: number,
): Promise<void> {
  const userRef = doc(db, "users", clerkUserId);
  const nextRefresh = new Date();
  nextRefresh.setMonth(nextRefresh.getMonth() + 1);

  await updateDoc(userRef, {
    subscriptionId,
    subscriptionPlan: plan,
    subscriptionStatus: "active",
    subscriptionPeriod: period,
    creditsRefreshDate: nextRefresh,
    credits: increment(creditsToAdd),
  });
}

export async function cancelSubscription(
  clerkUserId: string,
  endDate?: Date,
): Promise<void> {
  const userRef = doc(db, "users", clerkUserId);
  await updateDoc(userRef, {
    subscriptionStatus: "cancelled",
    subscriptionEndDate: endDate ?? null,
  });
}
/* -------------------------------------------------------
   Add credits to a user (called after payment).
------------------------------------------------------- */

export async function addCredits(
  clerkUserId: string,
  amount: number,
): Promise<void> {
  const userRef = doc(db, "users", clerkUserId);
  await updateDoc(userRef, {
    credits: increment(amount),
  });
}

export async function saveDeployedUrl(
  docId: string,
  clerkUserId: string,
  deployedUrl: string,
): Promise<void> {
  const ref = doc(db, "generations", docId);
  const snap = await getDoc(ref);

  if (!snap.exists()) throw new Error("Not found");
  if (snap.data().clerkUserId !== clerkUserId) throw new Error("Unauthorized");

  await updateDoc(ref, {
    deployedUrl,
    deployedAt: serverTimestamp(),
  });
}
