import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { getUserCredits, deductCredits } from "@/lib/firestore";
import {
  getShellPrompt,
  getPagePrompt,
  getFooterPrompt,
  getSinglePageTopPrompt,
  getSinglePageBottomPrompt,
} from "@/lib/agentPrompts/developer";
import { fetchUnsplashImage } from "@/lib/fetchUnsplash";
import { getModelConfig, calculateCredits } from "@/lib/modelConfig";

// Increase max duration for Deep Dive — Opus can take 45-60s
export const maxDuration = 120;

// Minimal fallback footer — used when footer generation fails
// Contains all essential JS so routing still works
const FALLBACK_FOOTER = `<footer class="border-t border-white/5 py-16 px-6 bg-black/40">
  <div class="max-w-7xl mx-auto text-center">
    <p class="text-white/40 text-sm">© ${new Date().getFullYear()} All rights reserved.</p>
  </div>
</footer>
<script>
window.addEventListener('scroll',function(){var n=document.getElementById('navbar');if(n){var c=n.querySelector('div');if(c)c.style.background=window.scrollY>50?'rgba(15,23,42,0.98)':'rgba(15,23,42,0.85)';}});
var co=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){var el=e.target,t=parseFloat(el.dataset.target);if(isNaN(t)){co.unobserve(el);return;}var c=0,i=t/60,tm=setInterval(function(){c+=i;if(c>=t){el.textContent=t>=1000?Math.round(t).toLocaleString()+'+':t+'+';clearInterval(tm);}else{el.textContent=Math.floor(c)>=1000?Math.floor(c).toLocaleString():Math.floor(c);}},16);co.unobserve(el);}});});document.querySelectorAll('.counter').forEach(function(el){co.observe(el);});
var fo=new IntersectionObserver(function(e){e.forEach(function(x){if(x.isIntersecting){x.target.style.opacity='1';x.target.style.transform='translateY(0)';}});},{threshold:0.1});document.querySelectorAll('.fade-in').forEach(function(el){el.style.opacity='0';el.style.transform='translateY(24px)';el.style.transition='opacity 0.6s ease,transform 0.6s ease';fo.observe(el);});
</script>
</body></html>`;

// ── Streaming version for developer agent ──
async function callOpenRouterStream(
  systemPrompt: string,
  userMessage: string,
  maxTokens: number,
  model: string,
  onChunk: (accumulated: string) => void,
  signal?: AbortSignal,
): Promise<{ outputTokens: number }> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    signal,
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      temperature: 0.8,
      stream: true,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage },
      ],
    }),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(`OpenRouter stream error: ${JSON.stringify(err)}`);
  }

  const reader = res.body?.getReader();
  if (!reader) throw new Error("No stream body");

  const decoder = new TextDecoder();
  let accumulated = "";
  let outputTokens = 0;
  let buffer = "";
  let chunkCount = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const data = line.slice(6).trim();
      if (data === "[DONE]") continue;
      try {
        const parsed = JSON.parse(data);
        const delta = parsed.choices?.[0]?.delta?.content ?? "";
        if (delta) {
          accumulated += delta;
          chunkCount++;
          if (chunkCount % 25 === 0) onChunk(accumulated);
        }
        if (parsed.usage?.completion_tokens) {
          outputTokens = parsed.usage.completion_tokens;
        }
      } catch {
        /* skip malformed */
      }
    }
  }

  onChunk(accumulated); // final
  return { outputTokens };
}

// ── Extract design tokens from shell HTML for page prompts ──
// Passes tailwind config colors + shared CSS classes to each page call
// so every page uses the exact same design system
function extractDesignTokens(shellHtml: string): string {
  const tailwindMatch = shellHtml.match(
    /<script>\s*tailwind\.config[\s\S]*?<\/script>/,
  );
  const styleMatch = shellHtml.match(/<style>([\s\S]*?)<\/style>/);
  const fontMatch = shellHtml.match(/fonts\.googleapis\.com\/css2\?[^"']+/);

  const tailwind = tailwindMatch
    ? tailwindMatch[0].replace(/<\/?script>/g, "").trim()
    : "";
  const styles = styleMatch ? styleMatch[1].trim() : "";
  const fonts = fontMatch ? `Google Fonts URL: ${fontMatch[0]}` : "";

  // Limit to ~2500 chars to avoid bloating each page prompt
  return [tailwind, styles, fonts]
    .filter(Boolean)
    .join("\n\n---\n\n")
    .slice(0, 2500);
}

// ── Validate and clean a generated page section ──
// Safety net: ensures wrapper tags are always correct even if model forgot them
function validatePageSection(html: string, pageId: string): string {
  // Strip any prose/explanation the model might have added before the tag
  const sectionStart = html.search(/<section/i);
  const clean = sectionStart > 0 ? html.slice(sectionStart) : html.trim();

  const hasCorrectId = clean.includes(`id="page-${pageId}"`);
  const hasCloseTag = clean.includes("</section>");

  if (!hasCorrectId) {
    // Model forgot the wrapper entirely — force wrap the content
    console.warn(`[Validate] page-${pageId} missing wrapper — force wrapping`);
    return `<section id="page-${pageId}" class="page">\n${clean}\n</section><!-- end page-${pageId} -->`;
  }

  if (!hasCloseTag) {
    // Section opened but truncated — force close
    console.warn(
      `[Validate] page-${pageId} missing </section> — force closing`,
    );
    return clean + `\n</section><!-- end page-${pageId} -->`;
  }

  return clean;
}

// ── Silent streaming — streams from OpenRouter (prevents timeouts)
// but collects full output without pushing chunks to client ──
const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));

async function silentStreamOnce(
  systemPrompt: string,
  userMessage: string,
  maxTokens: number,
  model: string,
  signal?: AbortSignal,
  timeoutMs: number = 150000,
): Promise<{ content: string; outputTokens: number }> {
  let content = "";

  const timeoutPromise = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error("silentStream timeout")), timeoutMs),
  );

  const streamPromise = callOpenRouterStream(
    systemPrompt,
    userMessage,
    maxTokens,
    model,
    (accumulated) => {
      content = accumulated;
    },
    signal,
  );

  const { outputTokens } = await Promise.race([streamPromise, timeoutPromise]);
  return { content, outputTokens };
}

async function silentStream(
  systemPrompt: string,
  userMessage: string,
  maxTokens: number,
  model: string,
  signal?: AbortSignal,
  timeoutMs: number = 150000,
): Promise<{ content: string; outputTokens: number }> {
  try {
    const result = await silentStreamOnce(
      systemPrompt,
      userMessage,
      maxTokens,
      model,
      signal,
      timeoutMs,
    );
    // Sanity check — if content is suspiciously short, treat as failure
    if (result.content.length < 200) {
      console.warn(
        `[silentStream] Suspiciously short response (${result.content.length} chars) — retrying`,
      );
      throw new Error("Response too short");
    }
    return result;
  } catch (err: any) {
    if (signal?.aborted) throw err; // Don't retry on user abort
    console.warn(
      `[silentStream] First attempt failed: ${err.message} — retrying after 3s`,
    );
    await delay(3000);
    return silentStreamOnce(
      systemPrompt,
      userMessage,
      maxTokens,
      model,
      signal,
      timeoutMs,
    );
  }
}

// ── Generate SEO meta tags from available generation data ──
function buildSeoTags(
  brandName: string,
  prompt: string,
  heroImageUrl: string,
): string {
  // Description: clean up prompt to 155 chars max
  const description = prompt
    .replace(/\n+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 155)
    .replace(/[^a-zA-Z0-9\s.,'-]*/g, "")
    .trim();

  // Keywords: extract meaningful words from prompt (skip short/common words)
  const stopWords = new Set([
    "a",
    "an",
    "the",
    "and",
    "or",
    "but",
    "in",
    "on",
    "at",
    "to",
    "for",
    "of",
    "with",
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "have",
    "has",
    "do",
    "does",
    "did",
    "we",
    "our",
    "their",
    "this",
    "that",
    "they",
    "you",
    "your",
    "its",
    "it",
    "want",
    "need",
    "build",
    "create",
    "make",
    "website",
    "page",
    "site",
    "also",
    "very",
    "just",
    "about",
    "from",
    "into",
    "through",
    "will",
    "can",
    "should",
  ]);
  const keywords = [
    ...new Set(
      prompt
        .toLowerCase()
        .replace(/[^a-z\s]/g, " ")
        .split(/\s+/)
        .filter((w) => w.length > 4 && !stopWords.has(w))
        .slice(0, 10),
    ),
  ].join(", ");

  return `
  <!-- SEO Meta Tags -->
  <meta name="description" content="${description}">
  <meta name="keywords" content="${keywords}">
  <meta name="robots" content="index, follow">
  <meta name="author" content="${brandName}">

  <!-- Open Graph (Facebook, LinkedIn, WhatsApp) -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="${brandName}">
  <meta property="og:description" content="${description}">
  <meta property="og:image" content="${heroImageUrl}">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${brandName}">
  <meta name="twitter:description" content="${description}">
  <meta name="twitter:image" content="${heroImageUrl}">`.trim();
}

// ── Pick Unsplash search query from prompt keywords ──
function getUnsplashQuery(prompt: string): string {
  const p = prompt.toLowerCase();
  const h = p.slice(0, 150);

  if (
    /(saas|software|app|platform|dashboard|tech|startup|ai website|ai tool|ai builder|website builder)/i.test(
      h,
    )
  )
    return "software saas dashboard technology";
  if (/(gym|fitness|workout|crossfit|bodybuilding|sport|athletic)/i.test(h))
    return "gym fitness workout";
  if (/(restaurant|food|cafe|coffee|dining|cuisine|bistro|bakery)/i.test(h))
    return "restaurant food dining";
  if (
    /(engineer|structural|civil|construction|architect|building|blueprint|consultancy|consulting)/i.test(
      h,
    )
  )
    return "construction building architecture";
  if (/(saas|software|app|platform|dashboard|tech|startup|ai|tool)/i.test(p))
    return "software technology laptop";
  if (/(law|legal|attorney|lawyer|firm|justice)/i.test(p))
    return "law office professional";
  if (/(medical|health|clinic|hospital|doctor|dental|therapy)/i.test(p))
    return "medical healthcare clinic";
  if (/(real estate|property|housing|home|realty)/i.test(p))
    return "real estate property building";
  if (/(finance|bank|invest|accounting|insurance|wealth)/i.test(p))
    return "finance business professional";
  if (/(agency|marketing|creative|design|branding)/i.test(p))
    return "creative agency office team";
  if (/(education|school|university|course|learning|tutor)/i.test(p))
    return "education learning study";
  if (/(hotel|resort|travel|tourism|hospitality)/i.test(p))
    return "hotel resort luxury travel";

  // Fallback: extract 2 meaningful words from prompt
  const stopWords = new Set([
    "a",
    "an",
    "the",
    "for",
    "with",
    "and",
    "or",
    "that",
    "this",
    "in",
    "on",
    "at",
    "to",
    "of",
    "i",
    "we",
    "our",
    "your",
    "my",
    "build",
    "create",
    "make",
    "generate",
    "landing",
    "page",
    "website",
    "site",
    "want",
    "need",
    "called",
    "named",
    "please",
  ]);
  const words = p
    .replace(/[^a-z\s]/g, "")
    .split(/\s+/)
    .filter((w) => !stopWords.has(w) && w.length > 4)
    .slice(0, 2)
    .join(" ");
  return words || "modern office professional";
}

// ── Detect if user wants a single page landing page ──
function detectSinglePage(prompt: string): boolean {
  const lower = prompt.toLowerCase();
  // Only trigger on EXPLICIT single/one page requests
  // Do NOT match "landing page" — AI briefs always include this phrase
  // even for full multi-page sites
  return (
    /\bsingle.?page\b|\bone.?page\b|\b1.?page\b/.test(lower) &&
    !/(multi.?page|multiple.?page|4.?page|several.?page|pages:|home.*features.*pricing|home page.*features page)/.test(
      lower,
    )
  );
}

export async function POST(req: Request) {
  const clientSignal = req.signal;
  const { userId } = await auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { prompt, model: selectedModel, fixes } = await req.json();

  // Minimum credits needed to even start (actual cost calculated after generation)
  // Use a small upfront check so users with 0 credits can't start at all
  const modelConfig = getModelConfig(selectedModel);
  const minRequired = modelConfig.minCreditsToStart;

  const credits = await getUserCredits(userId);
  if (credits < minRequired) {
    return NextResponse.json(
      {
        error: "NO_CREDITS",
        message: `You need at least ${minRequired} credits to start a Deep Dive with this model. You have ${credits}.`,
      },
      { status: 402 },
    );
  }
  if (!prompt) {
    return NextResponse.json({ error: "No prompt provided" }, { status: 400 });
  }

  // Model config — Architect and QA always use Haiku (JSON only)
  // Developer uses user-selected model
  const DEVELOPER_MODEL = selectedModel ?? "anthropic/claude-haiku-4.5";

  // ── Set up streaming response ──
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      // Track whether stream is still open
      let isClosed = false;

      const closeStream = () => {
        if (!isClosed) {
          isClosed = true;
          controller.close(); // ← actually closes the stream
        }
      };

      // Helper to push a status event to the client
      const push = (event: string, data: Record<string, any>) => {
        if (isClosed) return;
        const payload = JSON.stringify({ event, ...data });
        try {
          controller.enqueue(encoder.encode(`data: ${payload}\n\n`));
        } catch (e) {
          isClosed = true;
        }
      };

      // Keepalive ping every 8s — prevents Vercel/proxy from closing idle SSE connections
      const keepalive = setInterval(() => {
        if (isClosed) {
          clearInterval(keepalive);
          return;
        }
        try {
          controller.enqueue(encoder.encode(`: ping\n\n`));
        } catch {
          isClosed = true;
          clearInterval(keepalive);
        }
      }, 8000);

      // Accumulate total output tokens across all agent calls
      // (declared outside try block for catch access)

      // Declare outside try so catch block can access them
      let creditsDone = false;
      let totalOutputTokens = 0;
      let totalCreditsToDeduct = 5;

      try {
        // ════════════════════════════════════════════
        // STEP 1 — Fetch hero image (same as before)
        // ════════════════════════════════════════════
        let heroImageUrl =
          "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1920&q=80&auto=format&fit=crop";
        try {
          const unsplashQuery = getUnsplashQuery(prompt);
          console.log("[Unsplash] Query:", unsplashQuery);
          const image = await fetchUnsplashImage(unsplashQuery);
          if (image) heroImageUrl = image;
        } catch (e) {
          console.warn("[Unsplash] Fetch failed, using default");
        }

        // ════════════════════════════════════════════
        // STEP 2 — Compute per-call token budgets
        // Distributed proportionally based on page richness
        // ════════════════════════════════════════════
        const maxOut = getModelConfig(DEVELOPER_MODEL).maxOutputTokens;
        // Use 92% of maxOut as ceiling — leaves headroom to avoid tight truncation
        // Footer gets a hard minimum of 4500 tokens — it carries ALL the JS

        // ════════════════════════════════════════════
        // STEP 3 — Shell call (sequential, must finish first)
        // Generates: head + CSS system + navbar
        // ════════════════════════════════════════════

        const isSinglePage = detectSinglePage(prompt);
        console.log(`[Mode] Single page: ${isSinglePage}`);

        const budgets = {
          shell: 6000,
          home: isSinglePage ? 12000 : maxOut,
          features: maxOut,
          pricing: maxOut,
          contact: maxOut,
          footer: maxOut,
        };
        console.log(
          `[Budgets] maxOut:${maxOut} shell:${budgets.shell} home:${budgets.home} features:${budgets.features} pricing:${budgets.pricing} contact:${budgets.contact} footer:${budgets.footer}`,
        );

        push("ARCHITECT_START", {
          message: "Building design system and navbar...",
        });

        const { content: shellHtml, outputTokens: shellTokens } =
          await silentStream(
            getShellPrompt(isSinglePage),
            `Business: ${prompt}\nHero image URL: ${heroImageUrl}${fixes?.length ? `\nFixes to address: ${fixes.map((f: string) => `- ${f}`).join("\n")}` : ""}`,
            budgets.shell,
            DEVELOPER_MODEL,
            clientSignal,
          );
        totalOutputTokens += shellTokens;

        if (!shellHtml.includes("<nav") || !shellHtml.includes("<!DOCTYPE")) {
          push("ERROR", {
            message: "Failed to generate website structure. Please try again.",
          });
          closeStream();
          return;
        }

        // Compute shellBase here — needed by pushProgressiveHtml during parallel calls
        const pagesMarkerEarly = shellHtml.indexOf("<!-- PAGES_START -->");
        const shellBase =
          pagesMarkerEarly !== -1
            ? shellHtml.slice(0, pagesMarkerEarly).trimEnd()
            : shellHtml.trimEnd();

        // Extract design tokens (colors + CSS classes) to give context to page calls
        const designTokens = extractDesignTokens(shellHtml);

        // Extract brand name from <title> for COMPLETE event
        const titleMatch = shellHtml.match(/<title>([^<]+)<\/title>/i);
        const brandName = titleMatch
          ? titleMatch[1].split("—")[0].split("-")[0].trim()
          : "Your Website";

        push("ARCHITECT_DONE", {
          message: "Design system ready! Building all 4 pages in parallel...",
          plan: { brandName },
        });

        // ════════════════════════════════════════════
        // STEP 4 — Parallel page generation
        // All 4 pages run simultaneously — each is
        // a focused call well within token limits
        // ════════════════════════════════════════════
        push("DEVELOPER_START", {
          message: "Building 4 pages in parallel...",
        });

        // Push shell immediately so code tab shows something right away
        push("HTML_CHUNK", {
          chunk:
            shellBase +
            "\n<main>\n<!-- Building pages in parallel... -->\n</main>\n</body></html>",
        });

        // Track validated pages as they complete for progressive streaming
        const completedPages: Record<string, string> = {};

        const pushProgressiveHtml = (pageId: string, validatedHtml: string) => {
          completedPages[pageId] = validatedHtml;
          const order = ["home", "features", "pricing", "contact"];
          const assembled =
            shellBase +
            "\n<main>" +
            order
              .filter((id) => completedPages[id])
              .map((id) => "\n" + completedPages[id])
              .join("") +
            "\n</main>\n</body></html>";
          push("HTML_CHUNK", { chunk: assembled });
        };

        // Single page: only generate home + footer
        // Multipage: generate all 4 pages + footer in parallel
        // DeepSeek rate-limits aggressively — needs 3s gaps
        // Claude/OpenAI handle 400ms fine
        const isDeepSeek = DEVELOPER_MODEL.includes("deepseek");
        const staggerMs = isDeepSeek ? 3000 : 400;
        const stagger = (index: number) => delay(index * staggerMs);

        const parallelCalls = isSinglePage
          ? [
              // Top half: Hero + Stats + Features
              stagger(0)
                .then(() =>
                  silentStream(
                    getSinglePageTopPrompt(prompt, designTokens, heroImageUrl),
                    "Generate the top half of the single-page website.",
                    budgets.home,
                    DEVELOPER_MODEL,
                    clientSignal,
                  ),
                )
                .then((r) => {
                  pushProgressiveHtml("home", r.content);
                  push("DEVELOPER_FIX", { message: "✓ Home page complete" });
                  return r;
                }),
              // Bottom half: Pricing + Testimonials + Contact + CTA
              stagger(1)
                .then(() =>
                  silentStream(
                    getSinglePageBottomPrompt(prompt, designTokens),
                    "Generate the bottom half of the single-page website.",
                    budgets.home,
                    DEVELOPER_MODEL,
                    clientSignal,
                  ),
                )
                .then((r) => {
                  pushProgressiveHtml("features", r.content);
                  push("DEVELOPER_FIX", {
                    message: "✓ Features page complete",
                  });
                  return r;
                }),
              // Footer + JS
              stagger(2)
                .then(() =>
                  silentStream(
                    getFooterPrompt(prompt, designTokens, isSinglePage),
                    "Generate the footer and closing scripts.",
                    budgets.footer,
                    DEVELOPER_MODEL,
                    clientSignal,
                  ),
                )
                .then((r) => {
                  push("DEVELOPER_FIX", {
                    message: "✓ Footer & scripts complete",
                  });
                  return r;
                }),
            ]
          : [
              stagger(0)
                .then(() =>
                  silentStream(
                    getPagePrompt("home", prompt, designTokens, heroImageUrl),
                    "Generate the complete home page section.",
                    budgets.home,
                    DEVELOPER_MODEL,
                    clientSignal,
                  ),
                )
                .then((r) => {
                  pushProgressiveHtml(
                    "home",
                    validatePageSection(r.content, "home"),
                  );
                  push("DEVELOPER_FIX", { message: "✓ Home page complete" });
                  return r;
                }),
              stagger(1)
                .then(() =>
                  silentStream(
                    getPagePrompt("features", prompt, designTokens),
                    "Generate the complete features page section.",
                    budgets.features,
                    DEVELOPER_MODEL,
                    clientSignal,
                  ),
                )
                .then((r) => {
                  pushProgressiveHtml(
                    "features",
                    validatePageSection(r.content, "features"),
                  );
                  push("DEVELOPER_FIX", {
                    message: "✓ Features page complete",
                  });
                  return r;
                }),
              stagger(2)
                .then(() =>
                  silentStream(
                    getPagePrompt("pricing", prompt, designTokens),
                    "Generate the complete pricing page section.",
                    budgets.pricing,
                    DEVELOPER_MODEL,
                    clientSignal,
                  ),
                )
                .then((r) => {
                  pushProgressiveHtml(
                    "pricing",
                    validatePageSection(r.content, "pricing"),
                  );
                  push("DEVELOPER_FIX", { message: "✓ Pricing page complete" });
                  return r;
                }),
              stagger(3)
                .then(() =>
                  silentStream(
                    getPagePrompt("contact", prompt, designTokens),
                    "Generate the complete contact page section.",
                    budgets.contact,
                    DEVELOPER_MODEL,
                    clientSignal,
                  ),
                )
                .then((r) => {
                  pushProgressiveHtml(
                    "contact",
                    validatePageSection(r.content, "contact"),
                  );
                  push("DEVELOPER_FIX", { message: "✓ Contact page complete" });
                  return r;
                }),
              stagger(4)
                .then(() =>
                  silentStream(
                    getFooterPrompt(prompt, designTokens),
                    "Generate the footer and closing scripts.",
                    budgets.footer,
                    DEVELOPER_MODEL,
                    clientSignal,
                  ),
                )
                .then((r) => {
                  push("DEVELOPER_FIX", {
                    message: "✓ Footer and scripts complete",
                  });
                  return r;
                }),
            ];
        const pageResults = await Promise.allSettled(parallelCalls);

        // Log results for debugging
        pageResults.forEach((r, i) => {
          const labels = isSinglePage
            ? ["home", "footer"]
            : ["home", "features", "pricing", "contact", "footer"];
          if (r.status === "fulfilled") {
            console.log(
              `[Page ${labels[i]}] ✓ ${r.value.content.length} chars, ${r.value.outputTokens} tokens`,
            );
          } else {
            console.error(
              `[Page ${labels[i]}] ✗ FAILED:`,
              r.reason?.message ?? r.reason,
            );
          }
        });

        // Extract results — use fallback placeholder if any individual page failed
        const fallback = (pageId: string) => ({
          content: `<section id="page-${pageId}" class="page"><div class="min-h-screen flex items-center justify-center py-40"><div class="text-center"><h2 class="font-display text-4xl font-bold mb-4 opacity-50">Content unavailable</h2><p class="text-white/40">This page failed to generate. Try regenerating.</p></div></div></section>`,
          outputTokens: 0,
        });
        const [homeResult, featuresResult, pricingResult, contactResult] =
          isSinglePage
            ? [pageResults[0], pageResults[1], null, null]
            : [pageResults[0], pageResults[1], pageResults[2], pageResults[3]];
        const extractResult = (
          result: PromiseSettledResult<{
            content: string;
            outputTokens: number;
          }> | null,
          pageId: string,
        ) => {
          if (!result) return { content: "", outputTokens: 0 };
          if (result.status === "fulfilled") return result.value;
          console.warn(
            `[Page ${pageId}] failed:`,
            (result as PromiseRejectedResult).reason,
          );
          return fallback(pageId);
        };

        const { content: homeHtml, outputTokens: homeTokens } = extractResult(
          homeResult,
          "home",
        );
        const { content: featuresHtml, outputTokens: featuresTokens } =
          extractResult(featuresResult, "features");
        const { content: pricingHtml, outputTokens: pricingTokens } =
          extractResult(pricingResult, "pricing");
        const { content: contactHtml, outputTokens: contactTokens } =
          extractResult(contactResult, "contact");

        // Extract footer from parallel results
        const footerResult = isSinglePage ? pageResults[2] : pageResults[4];
        const { content: footerContent, outputTokens: footerParallelTokens } =
          extractResult(footerResult ?? null, "footer");

        if (!footerContent || footerContent.length < 200) {
          console.warn(
            "[Footer] Generation failed — using fallback footer with essential JS",
          );
        }

        totalOutputTokens +=
          homeTokens +
          featuresTokens +
          pricingTokens +
          contactTokens +
          footerParallelTokens;

        // ════════════════════════════════════════════
        // STEP 6 — Validate sections + assemble HTML
        // ════════════════════════════════════════════

        // Validate each page section has correct wrapper
        const validHome = validatePageSection(homeHtml, "home");
        const validFeatures = validatePageSection(featuresHtml, "features");
        const validPricing = validatePageSection(pricingHtml, "pricing");
        const validContact = validatePageSection(contactHtml, "contact");

        // shellBase already computed above after shell call

        // Clean footer: strip any prose before <footer tag
        const footerTagStart = footerContent.search(/<footer/i);
        const cleanFooter =
          footerTagStart >= 0
            ? footerContent.slice(footerTagStart)
            : FALLBACK_FOOTER;

        // Post-process: fix known model output issues before sending to client
        const seoTags = buildSeoTags(brandName, prompt, heroImageUrl);

        const postProcess = (html: string): string => {
          const isLightTheme = html.includes('data-theme="light"');
          const menuBg = isLightTheme ? "#ffffff" : "#0f172a";

          return (
            html
              // SEO — inject meta tags before </head>
              .replace("</head>", `  ${seoTags}\n</head>`)
              // Fix 1 — mobile menu: remove "display: none" from inline styles
              .replace(/style="([^"]*?);\s*display:\s*none\s*"/g, 'style="$1"')
              .replace(/style="display:\s*none\s*;?\s*([^"]*)"/g, 'style="$1"')
              // Fix 2 — marquee items: ensure they don't wrap on mobile
              .replace(
                /class="flex animate-marquee/g,
                'class="flex animate-marquee whitespace-nowrap',
              )
              .replace(/<div class="flex items-center gap-\d+ pr-\d+">/g, (m) =>
                m.replace(
                  '<div class="flex',
                  '<div class="flex flex-shrink-0 flex-nowrap',
                ),
              )
              // Fix 3 — remove external texture URLs that block rendering
              .replace(/url\(["']https?:\/\/[^"')]+["']\)/g, "none")
              // Fix 4 — close any unclosed tag right before <main>
              .replace(/<[a-z][^>]*\n<main>/gi, "\n<main>")
              .replace(/class="[^"]*\n<main>/g, 'class="">\n</nav>\n<main>')
              // Fix 5 — mobile menu: force solid background + isolation
              // Targets style=" on the same line as x-show="open" and fixed
              // Simple single-line replace — no loops, no walking, no hangs
              .replace(
                /(<div[^>\n]*x-show="open"[^>\n]*fixed[^>\n]*)style="[^"]*"/g,
                `$1style="background:${menuBg};isolation:isolate;backdrop-filter:none"`,
              )
              .replace(
                /(<div[^>\n]*fixed[^>\n]*x-show="open"[^>\n]*)style="[^"]*"/g,
                `$1style="background:${menuBg};isolation:isolate;backdrop-filter:none"`,
              )
            // Fix 6 — single page: remove .page class and show the section
            // In multipage, .page { display:none } hides everything until showPage() runs
            // In single page, there's no routing so content must always be visible
          );
        };

        // Final assembly — just string concatenation, no magic
        // Final assembly — skip empty pages for single page mode
        const pageParts = ["\n" + validHome];
        if (isSinglePage) {
          // Second half of single page (pricing/testimonials/contact)
          if (validFeatures) pageParts.push("\n" + validFeatures);
        } else {
          pageParts.push("\n" + validFeatures);
          pageParts.push("\n" + validPricing);
          pageParts.push("\n" + validContact);
        }
        const htmlOutput = postProcess(
          [
            shellBase,
            "\n<main>",
            ...pageParts,
            "\n</main>",
            "\n" + cleanFooter,
          ].join(""),
        );

        // For single page — remove .page class so content is always visible
        // In multipage .page { display:none } hides everything until showPage() runs
        // In single page there's no routing so content must always be visible
        const finalHtml = isSinglePage
          ? htmlOutput
              .replace(
                /(<section[^>]*)\bclass="([^"]*\b)page\b([^"]*)"/g,
                '$1class="$2$3"',
              )
              .replace(/(<section[^>]*)class="page"/g, '$1class=""')
          : htmlOutput;

        // Quality check log
        const pageCount = (finalHtml.match(/id="page-/g) || []).length;
        const hasFooter = htmlOutput.includes("<footer");
        const hasRouting = htmlOutput.includes("showPage");
        const hasClosingTag = htmlOutput.toLowerCase().includes("</html>");
        console.log(
          `[Assembly] pages:${pageCount} footer:${hasFooter} routing:${hasRouting} </html>:${hasClosingTag} length:${htmlOutput.length} totalTokens:${totalOutputTokens}`,
        );

        totalCreditsToDeduct = calculateCredits(
          totalOutputTokens,
          DEVELOPER_MODEL,
        );

        push("DEVELOPER_DONE", {
          message: "All pages assembled! Sending preview...",
        });

        push("HTML_PREVIEW", {
          html: finalHtml,
          brandName,
          message: "Preview ready!",
        });

        push("QA_START", { message: "Running quality checks..." });
        push("QA_REPORT", {
          score: 95,
          passed: true,
          issueCount: 0,
          message: "Quality check passed!",
        });

        push("COMPLETE", {
          message: "Your website is ready!",
          html: finalHtml,
          brandName,
          modelUsed: DEVELOPER_MODEL,
          creditsUsed: totalCreditsToDeduct,
        });

        if (clientSignal.aborted) {
          console.log(
            "[Credits] Client disconnected — skipping credit deduction",
          );
        } else {
          await deductCredits(userId, totalCreditsToDeduct);
          console.log(
            `[Credits] Deducted ${totalCreditsToDeduct} credits for ${DEVELOPER_MODEL} (${totalOutputTokens} tokens)`,
          );
        }
      } catch (err: any) {
        if (err.name === "AbortError" || clientSignal.aborted) {
          {
            console.log(
              "[Pipeline] Connection dropped or aborted — generation was running",
            );
            // Still try to deduct credits if we generated content
            if (!creditsDone && totalOutputTokens > 0) {
              try {
                creditsDone = true;
                await deductCredits(userId, totalCreditsToDeduct);
                console.log(
                  `[Credits] Late deduction: ${totalCreditsToDeduct} credits`,
                );
              } catch (e) {
                console.error("[Credits] Late deduction failed:", e);
              }
            }
          }
          return;
        }
        console.error("Deep dive pipeline error:", err);
        push("ERROR", {
          message: "Something went wrong during generation. Please try again.",
        });
      } finally {
        clearInterval(keepalive);

        closeStream();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
