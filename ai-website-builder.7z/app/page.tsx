import Home from "@/components/Home";

export default async function page() {
  return <Home />;
}
