"use client";

import { useEffect, useRef } from "react";

export default function DeepPreview({
  html,
  viewport = "desktop",
}: {
  html: string;
  viewport?: "desktop" | "mobile";
}) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const blobUrlRef = useRef<string | null>(null);

  useEffect(() => {
    const iframe = iframeRef.current;
    if (!iframe || !html) return;

    // Revoke previous blob URL to free memory
    if (blobUrlRef.current) {
      URL.revokeObjectURL(blobUrlRef.current);
    }

    // Inject preview-specific CSS fixes
    // These only affect the iframe preview — downloaded HTML is unchanged
    const previewPatch = `
<style id="crawlcube-preview-patch">
  /* Fix: 100vh in iframe grows with content — cap hero to real screen height */
  section:first-of-type,
  .hero, [class*="hero"], section.relative.min-h-screen:first-of-type {
    min-height: 100svh !important;
    max-height: 100svh !important;
    overflow: hidden !important;
  }
  /* Fix: ensure ticker/content after hero is not hidden behind overflow:hidden */
  section:first-of-type ~ section:first-of-type,
  section:first-of-type + *,
  .hero + *, [class*="hero"] + * {
    overflow: visible !important;
    max-height: none !important;
  }
</style>`;

    const patchedHtml = html.includes("</head>")
      ? html.replace("</head>", `${previewPatch}\n</head>`)
      : previewPatch + html;

    const blob = new Blob([patchedHtml], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    blobUrlRef.current = url;
    iframe.src = url;

    // Cleanup on unmount
    return () => {
      if (blobUrlRef.current) {
        URL.revokeObjectURL(blobUrlRef.current);
      }
    };
  }, [html]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <iframe
      ref={iframeRef}
      className="rounded-lg shadow-2xl transition-all duration-300 border-0"
      style={{
        width: viewport === "mobile" ? "390px" : "100%",
        height: "100%",
        minHeight: "600px",
        background: "white",
        display: "block",
      }}
      sandbox="allow-scripts allow-same-origin allow-forms"
      title="Deep Dive Preview"
    />
  );
}
