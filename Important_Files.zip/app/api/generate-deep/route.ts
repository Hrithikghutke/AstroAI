import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { getUserCredits, deductCredits } from "@/lib/firestore";
import {
  getShellPrompt,
  getPagePrompt,
  getFooterPrompt,
  getSinglePageTopPrompt,
  getSinglePageBottomPrompt,
} from "@/lib/agentPrompts/developer";
import {
  getArchitectPrompt,
  type ArchitectOutput,
} from "@/lib/agentPrompts/architect";
import {
  getContentStrategistPrompt,
  type ContentBrief,
} from "@/lib/agentPrompts/contentStrategist";
import {
  getUIDesignerPrompt,
  type UIDesignSpec,
} from "@/lib/agentPrompts/uiDesigner";
import { fetchUnsplashImage } from "@/lib/fetchUnsplash";
import { getModelConfig, calculateCredits } from "@/lib/modelConfig";

// Increase max duration for Deep Dive — Opus can take 45-60s
export const maxDuration = 300;

// Minimal fallback footer — used when footer generation fails
// Contains all essential JS so routing still works
const FALLBACK_FOOTER = `<footer class="border-t border-white/5 py-16 px-6 bg-black/40">
  <div class="max-w-7xl mx-auto text-center">
    <p class="text-white/40 text-sm">© ${new Date().getFullYear()} All rights reserved.</p>
  </div>
</footer>
<script>
window.addEventListener('scroll',function(){var n=document.getElementById('navbar');if(n){var c=n.querySelector('div');if(c)c.style.background=window.scrollY>50?'rgba(15,23,42,0.98)':'rgba(15,23,42,0.85)';}});
var co=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){var el=e.target,t=parseFloat(el.dataset.target);if(isNaN(t)){co.unobserve(el);return;}var c=0,i=t/60,tm=setInterval(function(){c+=i;if(c>=t){el.textContent=t>=1000?Math.round(t).toLocaleString()+'+':t+'+';clearInterval(tm);}else{el.textContent=Math.floor(c)>=1000?Math.floor(c).toLocaleString():Math.floor(c);}},16);co.unobserve(el);}});});document.querySelectorAll('.counter').forEach(function(el){co.observe(el);});
var fo=new IntersectionObserver(function(e){e.forEach(function(x){if(x.isIntersecting){x.target.style.opacity='1';x.target.style.transform='translateY(0)';}});},{threshold:0.1});document.querySelectorAll('.fade-in').forEach(function(el){el.style.opacity='0';el.style.transform='translateY(24px)';el.style.transition='opacity 0.6s ease,transform 0.6s ease';fo.observe(el);});
</script>
</body></html>`;

// ── Streaming version for developer agent ──
async function callOpenRouterStream(
  systemPrompt: string,
  userMessage: string,
  maxTokens: number,
  model: string,
  onChunk: (accumulated: string) => void,
  signal?: AbortSignal,
): Promise<{ outputTokens: number }> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    signal,
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      temperature: 0.8,
      stream: true,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage },
      ],
    }),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(`OpenRouter stream error: ${JSON.stringify(err)}`);
  }

  const reader = res.body?.getReader();
  if (!reader) throw new Error("No stream body");

  const decoder = new TextDecoder();
  let accumulated = "";
  let outputTokens = 0;
  let buffer = "";
  let chunkCount = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const data = line.slice(6).trim();
      if (data === "[DONE]") continue;
      try {
        const parsed = JSON.parse(data);
        const delta = parsed.choices?.[0]?.delta?.content ?? "";
        if (delta) {
          accumulated += delta;
          chunkCount++;
          if (chunkCount % 25 === 0) onChunk(accumulated);
        }
        if (parsed.usage?.completion_tokens) {
          outputTokens = parsed.usage.completion_tokens;
        }
      } catch {
        /* skip malformed */
      }
    }
  }

  onChunk(accumulated); // final
  return { outputTokens };
}

// ── Non-streaming JSON call — used for Architect (Haiku, fast, cheap) ──
async function callOpenRouterJson(
  systemPrompt: string,
  userMessage: string,
  signal?: AbortSignal,
  maxTokens: number = 1000,
): Promise<string> {
  const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    signal,
    headers: {
      Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "anthropic/claude-haiku-4.5", // Always Haiku — fast and cheap for JSON
      max_tokens: maxTokens,
      temperature: 0.7,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage },
      ],
    }),
  });
  const data = await res.json();
  return data.choices?.[0]?.message?.content ?? "";
}

// ── Default architect fallback ──
function defaultArchitect(prompt: string): ArchitectOutput {
  const isTech = /(saas|tech|software|app|startup)/i.test(prompt);
  const isFood = /(restaurant|cafe|food|dining)/i.test(prompt);
  const isGym = /(gym|fitness|workout)/i.test(prompt);
  const isConstruction = /(construction|engineering|architect|structural)/i.test(prompt);
  const isLaw = /(law|legal|attorney|lawyer)/i.test(prompt);
  return {
    brandName: "Your Brand",
    theme: "dark",
    visualMood: isTech ? "editorial-clean" : isGym ? "bold-energy" : isConstruction ? "cinematic-dark" : isLaw ? "corporate-precision" : "cinematic-dark",
    colors: {
      primary: isTech ? "#7C3AED" : isFood ? "#C8956C" : isGym ? "#E8FF47" : isConstruction ? "#7FA67A" : isLaw ? "#8BA3BE" : "#6366F1",
      secondary: "#8B5CF6",
      background: "#060606",
      surface: "#0F0F0F",
    },
    fonts: {
      display: isTech ? "Space Grotesk" : isFood ? "Cormorant Garamond" : isGym ? "Barlow Condensed" : isConstruction ? "Bebas Neue" : "Inter",
      body: isTech ? "DM Sans" : isFood ? "Lato" : isGym ? "Barlow" : "Inter",
      url: "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap",
    },
    pages: [
      "home",
      isTech ? "features" : isFood ? "menu" : "services",
      isTech ? "pricing" : "projects",
      "contact",
    ],
    pageLabels: [
      "Home",
      isTech ? "Features" : isFood ? "Menu" : "Services",
      isTech ? "Pricing" : "Projects",
      "Contact",
    ],
  };
}

// ── Extract design tokens from shell HTML for page prompts ──

// ── Extract design tokens from shell HTML for page prompts ──
// Passes tailwind config colors + shared CSS classes to each page call
// so every page uses the exact same design system
function extractDesignTokens(shellHtml: string): string {
  const tailwindMatch = shellHtml.match(
    /<script>\s*tailwind\.config[\s\S]*?<\/script>/,
  );
  const styleMatch = shellHtml.match(/<style>([\s\S]*?)<\/style>/);
  const fontMatch = shellHtml.match(/fonts\.googleapis\.com\/css2\?[^"']+/);

  const tailwind = tailwindMatch
    ? tailwindMatch[0].replace(/<\/?script>/g, "").trim()
    : "";
  const styles = styleMatch ? styleMatch[1].trim() : "";
  const fonts = fontMatch ? `Google Fonts URL: ${fontMatch[0]}` : "";

  // Limit to ~2500 chars to avoid bloating each page prompt
  return [tailwind, styles, fonts]
    .filter(Boolean)
    .join("\n\n---\n\n")
    .slice(0, 2500);
}

// ── Validate and clean a generated page section ──
// Safety net: ensures wrapper tags are always correct even if model forgot them
function validatePageSection(html: string, pageId: string): string {
  // Strip any prose/explanation the model might have added before the tag
  const sectionStart = html.search(/<section/i);
  const clean = sectionStart > 0 ? html.slice(sectionStart) : html.trim();

  const hasCorrectId = clean.includes(`id="page-${pageId}"`);
  const hasCloseTag = clean.includes("</section>");

  if (!hasCorrectId) {
    // Model forgot the wrapper entirely — force wrap the content
    console.warn(`[Validate] page-${pageId} missing wrapper — force wrapping`);
    return `<section id="page-${pageId}" class="page">\n${clean}\n</section><!-- end page-${pageId} -->`;
  }

  if (!hasCloseTag) {
    // Section opened but truncated — force close
    console.warn(
      `[Validate] page-${pageId} missing </section> — force closing`,
    );
    return clean + `\n</section><!-- end page-${pageId} -->`;
  }

  return clean;
}

// ── Silent streaming — streams from OpenRouter (prevents timeouts)
// but collects full output without pushing chunks to client ──
const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));

async function silentStreamOnce(
  systemPrompt: string,
  userMessage: string,
  maxTokens: number,
  model: string,
  signal?: AbortSignal,
  timeoutMs: number = 150000,
): Promise<{ content: string; outputTokens: number }> {
  let content = "";

  const timeoutPromise = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error("silentStream timeout")), timeoutMs),
  );

  const streamPromise = callOpenRouterStream(
    systemPrompt,
    userMessage,
    maxTokens,
    model,
    (accumulated) => {
      content = accumulated;
    },
    signal,
  );

  const { outputTokens } = await Promise.race([streamPromise, timeoutPromise]);
  return { content, outputTokens };
}

async function silentStream(
  systemPrompt: string,
  userMessage: string,
  maxTokens: number,
  model: string,
  signal?: AbortSignal,
  timeoutMs: number = 150000,
): Promise<{ content: string; outputTokens: number }> {
  try {
    const result = await silentStreamOnce(
      systemPrompt,
      userMessage,
      maxTokens,
      model,
      signal,
      timeoutMs,
    );
    // Sanity check — if content is suspiciously short, treat as failure
    if (result.content.length < 200) {
      console.warn(
        `[silentStream] Suspiciously short response (${result.content.length} chars) — retrying`,
      );
      throw new Error("Response too short");
    }
    return result;
  } catch (err: any) {
    if (signal?.aborted) throw err; // Don't retry on user abort
    console.warn(
      `[silentStream] First attempt failed: ${err.message} — retrying after 3s`,
    );
    await delay(3000);
    return silentStreamOnce(
      systemPrompt,
      userMessage,
      maxTokens,
      model,
      signal,
      timeoutMs,
    );
  }
}

// ── Generate SEO meta tags from available generation data ──
function buildSeoTags(
  brandName: string,
  prompt: string,
  heroImageUrl: string,
): string {
  // Description: clean up prompt to 155 chars max
  const description = prompt
    .replace(/\n+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 155)
    .replace(/[^a-zA-Z0-9\s.,'-]*/g, "")
    .trim();

  // Keywords: extract meaningful words from prompt (skip short/common words)
  const stopWords = new Set([
    "a",
    "an",
    "the",
    "and",
    "or",
    "but",
    "in",
    "on",
    "at",
    "to",
    "for",
    "of",
    "with",
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "have",
    "has",
    "do",
    "does",
    "did",
    "we",
    "our",
    "their",
    "this",
    "that",
    "they",
    "you",
    "your",
    "its",
    "it",
    "want",
    "need",
    "build",
    "create",
    "make",
    "website",
    "page",
    "site",
    "also",
    "very",
    "just",
    "about",
    "from",
    "into",
    "through",
    "will",
    "can",
    "should",
  ]);
  const keywords = [
    ...new Set(
      prompt
        .toLowerCase()
        .replace(/[^a-z\s]/g, " ")
        .split(/\s+/)
        .filter((w) => w.length > 4 && !stopWords.has(w))
        .slice(0, 10),
    ),
  ].join(", ");

  return `
  <!-- SEO Meta Tags -->
  <meta name="description" content="${description}">
  <meta name="keywords" content="${keywords}">
  <meta name="robots" content="index, follow">
  <meta name="author" content="${brandName}">

  <!-- Open Graph (Facebook, LinkedIn, WhatsApp) -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="${brandName}">
  <meta property="og:description" content="${description}">
  <meta property="og:image" content="${heroImageUrl}">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${brandName}">
  <meta name="twitter:description" content="${description}">
  <meta name="twitter:image" content="${heroImageUrl}">`.trim();
}

// ── Pick Unsplash search query from prompt keywords ──
function getUnsplashQuery(prompt: string): string {
  const p = prompt.toLowerCase();
  const h = p.slice(0, 150);

  if (
    /(saas|software|app|platform|dashboard|tech|startup|ai website|ai tool|ai builder|website builder)/i.test(
      h,
    )
  )
    return "software saas dashboard technology";
  if (/(gym|fitness|workout|crossfit|bodybuilding|sport|athletic)/i.test(h))
    return "gym fitness workout";
  if (/(restaurant|food|cafe|coffee|dining|cuisine|bistro|bakery)/i.test(h))
    return "restaurant food dining";
  if (
    /(engineer|structural|civil|construction|architect|building|blueprint|consultancy|consulting)/i.test(
      h,
    )
  )
    return "construction building architecture";
  if (/(saas|software|app|platform|dashboard|tech|startup|ai|tool)/i.test(p))
    return "software technology laptop";
  if (/(law|legal|attorney|lawyer|firm|justice)/i.test(p))
    return "law office professional";
  if (/(medical|health|clinic|hospital|doctor|dental|therapy)/i.test(p))
    return "medical healthcare clinic";
  if (/(real estate|property|housing|home|realty)/i.test(p))
    return "real estate property building";
  if (/(finance|bank|invest|accounting|insurance|wealth)/i.test(p))
    return "finance business professional";
  if (/(agency|marketing|creative|design|branding)/i.test(p))
    return "creative agency office team";
  if (/(education|school|university|course|learning|tutor)/i.test(p))
    return "education learning study";
  if (/(hotel|resort|travel|tourism|hospitality)/i.test(p))
    return "hotel resort luxury travel";

  // Fallback: extract 2 meaningful words from prompt
  const stopWords = new Set([
    "a",
    "an",
    "the",
    "for",
    "with",
    "and",
    "or",
    "that",
    "this",
    "in",
    "on",
    "at",
    "to",
    "of",
    "i",
    "we",
    "our",
    "your",
    "my",
    "build",
    "create",
    "make",
    "generate",
    "landing",
    "page",
    "website",
    "site",
    "want",
    "need",
    "called",
    "named",
    "please",
  ]);
  const words = p
    .replace(/[^a-z\s]/g, "")
    .split(/\s+/)
    .filter((w) => !stopWords.has(w) && w.length > 4)
    .slice(0, 2)
    .join(" ");
  return words || "modern office professional";
}

// ── Detect if user wants a single page landing page ──
function detectSinglePage(prompt: string): boolean {
  const lower = prompt.toLowerCase();
  // Only trigger on EXPLICIT single/one page requests
  // Do NOT match "landing page" — AI briefs always include this phrase
  // even for full multi-page sites
  return (
    /\bsingle.?page\b|\bone.?page\b|\b1.?page\b/.test(lower) &&
    !/(multi.?page|multiple.?page|4.?page|several.?page|pages:|home.*features.*pricing|home page.*features page)/.test(
      lower,
    )
  );
}

export async function POST(req: Request) {
  const clientSignal = req.signal;
  const { userId } = await auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { prompt, model: selectedModel, fixes } = await req.json();

  // Minimum credits needed to even start (actual cost calculated after generation)
  // Use a small upfront check so users with 0 credits can't start at all
  const modelConfig = getModelConfig(selectedModel);
  const minRequired = modelConfig.minCreditsToStart;

  const credits = await getUserCredits(userId);
  if (credits < minRequired) {
    return NextResponse.json(
      {
        error: "NO_CREDITS",
        message: `You need at least ${minRequired} credits to start a Deep Dive with this model. You have ${credits}.`,
      },
      { status: 402 },
    );
  }
  if (!prompt) {
    return NextResponse.json({ error: "No prompt provided" }, { status: 400 });
  }

  // Model config — Architect and QA always use Haiku (JSON only)
  // Developer uses user-selected model
  const DEVELOPER_MODEL = selectedModel ?? "anthropic/claude-haiku-4.5";

  // ── Set up streaming response ──
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      // Track whether stream is still open
      let isClosed = false;

      const closeStream = () => {
        if (!isClosed) {
          isClosed = true;
          controller.close(); // ← actually closes the stream
        }
      };

      // Helper to push a status event to the client
      const push = (event: string, data: Record<string, any>) => {
        if (isClosed) return;
        const payload = JSON.stringify({ event, ...data });
        try {
          controller.enqueue(encoder.encode(`data: ${payload}\n\n`));
        } catch (e) {
          isClosed = true;
        }
      };

      // Keepalive ping every 8s — prevents Vercel/proxy from closing idle SSE connections
      const keepalive = setInterval(() => {
        if (isClosed) {
          clearInterval(keepalive);
          return;
        }
        try {
          controller.enqueue(encoder.encode(`: ping\n\n`));
        } catch {
          isClosed = true;
          clearInterval(keepalive);
        }
      }, 8000);

      // Accumulate total output tokens across all agent calls
      // (declared outside try block for catch access)

      // Declare outside try so catch block can access them
      let creditsDone = false;
      let totalOutputTokens = 0;
      let totalCreditsToDeduct = 5;

      try {
        // ════════════════════════════════════════════
        // STEP 1 — Fetch hero image (same as before)
        // ════════════════════════════════════════════
        let heroImageUrl =
          "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1920&q=80&auto=format&fit=crop";
        try {
          const unsplashQuery = getUnsplashQuery(prompt);
          console.log("[Unsplash] Query:", unsplashQuery);
          const image = await fetchUnsplashImage(unsplashQuery);
          if (image) heroImageUrl = image;
        } catch (e) {
          console.warn("[Unsplash] Fetch failed, using default");
        }

        // ════════════════════════════════════════════
        // STEP 2 — Compute per-call token budgets
        // Distributed proportionally based on page richness
        // ════════════════════════════════════════════
        const maxOut = getModelConfig(DEVELOPER_MODEL).maxOutputTokens;
        // Use 92% of maxOut as ceiling — leaves headroom to avoid tight truncation
        // Footer gets a hard minimum of 4500 tokens — it carries ALL the JS

        // ════════════════════════════════════════════
        // STEP 3 — Shell call (sequential, must finish first)
        // Generates: head + CSS system + navbar
        // ════════════════════════════════════════════
        const isSinglePage = detectSinglePage(prompt);
        const isDeepSeek = DEVELOPER_MODEL.includes("deepseek");
        console.log(
          `[Mode] Single page: ${isSinglePage} | Model: ${isDeepSeek ? "DeepSeek (sequential)" : "Fast (parallel)"}`,
        );

        const budgets = {
          shell: 6000,
          page: isSinglePage ? 12000 : maxOut,
          footer: maxOut,
        };
        console.log(
          `[Budgets] maxOut:${maxOut} shell:${budgets.shell} page:${budgets.page} footer:${budgets.footer}`,
        );

        // ════════════════════════════════════════════
        // STEP 2 — REAL Architect call (Haiku, ~3s)
        // Decides: brand, colors, fonts, page structure
        // ════════════════════════════════════════════
        push("ARCHITECT_START", {
          message: "Analyzing business and planning website structure...",
        });

        let architect: ArchitectOutput;
        try {
          const rawArchitect = await callOpenRouterJson(
            getArchitectPrompt(),
            `Business to build a website for: ${prompt}`,
            clientSignal,
          );
          const clean = rawArchitect
            .replace(/^```json\s*/i, "")
            .replace(/```\s*$/i, "")
            .trim();
          const parsed = JSON.parse(clean);
          // Validate required fields
          if (
            !parsed.pages?.length ||
            !parsed.colors?.primary ||
            !parsed.fonts?.display
          ) {
            throw new Error("Incomplete architect output");
          }
          architect = parsed as ArchitectOutput;
          console.log(
            `[Architect] Pages: ${architect.pages.join(", ")} | Brand: ${architect.brandName} | Primary: ${architect.colors.primary}`,
          );
        } catch (err) {
          console.warn(
            "[Architect] Failed or incomplete — using smart fallback:",
            err,
          );
          architect = defaultArchitect(prompt);
        }

        // Tell ChatPanel the real page names so step labels update
        push("PAGE_NAMES", {
          pages: architect.pages,
          pageLabels: architect.pageLabels,
        });

        // ════════════════════════════════════════════
        // STEP 2b + 2c — Content Strategist + UI Designer
        // Run in parallel with each other, THEN shell uses UI spec.
        // Both are cheap Haiku calls (<1 credit each).
        // ════════════════════════════════════════════
        let contentBrief: ContentBrief | undefined;
        let uiSpec: UIDesignSpec | undefined;

        try {
          const [rawContent, rawUISpec] = await Promise.all([
            callOpenRouterJson(
              getContentStrategistPrompt(),
              `Business: ${prompt}`,
              clientSignal,
              700,
            ),
            callOpenRouterJson(
              getUIDesignerPrompt(),
              `Business: ${prompt}\n\nBrand plan from Architect:\n${JSON.stringify({ brandName: architect.brandName, visualMood: architect.visualMood, colors: architect.colors, fonts: { display: architect.fonts.display, body: architect.fonts.body } }, null, 2)}`,
              clientSignal,
              1000,
            ),
          ]);

          try {
            const cleanContent = rawContent.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim();
            contentBrief = JSON.parse(cleanContent) as ContentBrief;
            console.log(`[ContentStrategist] tagline: "${contentBrief.tagline}"`);
            push("CONTENT_STRATEGIST_DONE", { tagline: contentBrief.tagline });
          } catch {
            console.warn("[ContentStrategist] Failed to parse — using developer defaults");
            push("CONTENT_STRATEGIST_DONE", { tagline: null });
          }

          try {
            const cleanUI = rawUISpec.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim();
            uiSpec = JSON.parse(cleanUI) as UIDesignSpec;
            console.log(`[UIDesigner] hero: ${uiSpec.heroVariant} | features: ${uiSpec.featuresVariant} | navbar: ${uiSpec.navbarStyle}`);
            push("UI_DESIGNER_DONE", {
              heroVariant: uiSpec.heroVariant,
              featuresVariant: uiSpec.featuresVariant,
              navbarStyle: uiSpec.navbarStyle,
            });
          } catch {
            console.warn("[UIDesigner] Failed to parse — using developer defaults");
            push("UI_DESIGNER_DONE", { heroVariant: null, featuresVariant: null });
          }
        } catch (err) {
          console.warn("[Parallel agents] Failed:", err);
          push("CONTENT_STRATEGIST_DONE", { tagline: null });
          push("UI_DESIGNER_DONE", { heroVariant: null, featuresVariant: null });
        }

        // ════════════════════════════════════════════
        // STEP 3 — Shell call (receives UI spec for navbar style)
        // ════════════════════════════════════════════
        const { content: shellHtml, outputTokens: shellTokens } =
          await silentStream(
            getShellPrompt(isSinglePage, architect, uiSpec),
            `Business: ${prompt}\nHero image URL: ${heroImageUrl}${fixes?.length ? `\nFixes to address: ${fixes.map((f: string) => `- ${f}`).join("\n")}` : ""}`,
            budgets.shell,
            DEVELOPER_MODEL,
            clientSignal,
          );
        totalOutputTokens += shellTokens;

        if (!shellHtml.includes("<nav") || !shellHtml.includes("<!DOCTYPE")) {
          push("ERROR", {
            message: "Failed to generate website structure. Please try again.",
          });
          closeStream();
          return;
        }

        const pagesMarkerEarly = shellHtml.indexOf("<!-- PAGES_START -->");
        const shellBase =
          pagesMarkerEarly !== -1
            ? shellHtml.slice(0, pagesMarkerEarly).trimEnd()
            : shellHtml.trimEnd();

        const designTokens = extractDesignTokens(shellHtml);

        // Use architect's brandName — more reliable than parsing <title>
        const brandName = architect.brandName;

        push("ARCHITECT_DONE", {
          message: `Structure ready! Building ${architect.pages.length} pages: ${architect.pageLabels.join(", ")}`,
          plan: {
            brandName,
            overallStyle: `${architect.fonts.display} · ${architect.colors.primary}`,
          },
          architectData: {
            brandName: architect.brandName,
            colors: architect.colors,
            fonts: {
              display: architect.fonts.display,
              body: architect.fonts.body,
            },
            pages: architect.pages,
            pageLabels: architect.pageLabels,
          },
        });

        // ════════════════════════════════════════════
        // STEP 4 — Parallel page generation
        // All 4 pages run simultaneously — each is
        // a focused call well within token limits
        // ════════════════════════════════════════════
        push("DEVELOPER_START", {
          message: "Building 4 pages in parallel...",
        });

        // Push shell immediately so code tab shows something right away
        // Push shell immediately so code tab shows something right away
        push("HTML_CHUNK", {
          chunk:
            shellBase +
            "\n<main>\n<!-- Building pages... -->\n</main>\n</body></html>",
        });

        // Track completed pages for progressive preview streaming
        const completedPages: Record<string, string> = {};
        const pushProgressiveHtml = (pageId: string, validatedHtml: string) => {
          completedPages[pageId] = validatedHtml;
          const assembled =
            shellBase +
            "\n<main>" +
            architect.pages
              .filter((id) => completedPages[id])
              .map((id) => "\n" + completedPages[id])
              .join("") +
            "\n</main>\n</body></html>";
          push("HTML_CHUNK", { chunk: assembled });
        };

        const staggerMs = isDeepSeek ? 0 : 400;
        const stagger = (index: number) => delay(index * staggerMs);
        const callTimeout = isDeepSeek ? 200000 : 150000;

        let pageResults: PromiseSettledResult<{
          content: string;
          outputTokens: number;
        }>[];

        if (isSinglePage) {
          // ── Single page: 3 parallel calls (top half + bottom half + footer) ──
          const singleCalls = [
            stagger(0)
              .then(() =>
                silentStream(
                  getSinglePageTopPrompt(prompt, designTokens, heroImageUrl),
                  "Generate the top half.",
                  budgets.page,
                  DEVELOPER_MODEL,
                  clientSignal,
                  callTimeout,
                ),
              )
              .then((r) => {
                pushProgressiveHtml("home", r.content);
                push("DEVELOPER_FIX", {
                  stepId: "page-home",
                  message: "✓ Home complete",
                });
                return r;
              }),
            stagger(1)
              .then(() =>
                silentStream(
                  getSinglePageBottomPrompt(prompt, designTokens),
                  "Generate the bottom half.",
                  budgets.page,
                  DEVELOPER_MODEL,
                  clientSignal,
                  callTimeout,
                ),
              )
              .then((r) => {
                pushProgressiveHtml("features", r.content);
                push("DEVELOPER_FIX", {
                  stepId: "page-2",
                  message: "✓ Bottom half complete",
                });
                return r;
              }),
            stagger(2)
              .then(() =>
                silentStream(
                  getFooterPrompt(prompt, designTokens, true),
                  "Generate footer and scripts.",
                  budgets.footer,
                  DEVELOPER_MODEL,
                  clientSignal,
                  callTimeout,
                ),
              )
              .then((r) => {
                push("DEVELOPER_FIX", {
                  stepId: "page-footer",
                  message: "✓ Footer complete",
                });
                return r;
              }),
          ];
          pageResults = await Promise.allSettled(singleCalls);
        } else if (isDeepSeek) {
          // ── DeepSeek: SEQUENTIAL to avoid rate limiting ──
          pageResults = [];
          for (let i = 0; i < architect.pages.length; i++) {
            const pageId = architect.pages[i];
            const pageLabel = architect.pageLabels[i];
            const heroUrl = pageId === "home" ? heroImageUrl : undefined;
            try {
              const r = await silentStream(
                getPagePrompt(pageId, pageLabel, prompt, designTokens, heroUrl, architect, uiSpec, contentBrief),
                `Generate the complete ${pageLabel} page section.`,
                budgets.page,
                DEVELOPER_MODEL,
                clientSignal,
                callTimeout,
              );
              pushProgressiveHtml(
                pageId,
                validatePageSection(r.content, pageId),
              );
              push("DEVELOPER_FIX", {
                stepId: `page-${pageId}`,
                message: `✓ ${pageLabel} page complete`,
              });
              pageResults.push({ status: "fulfilled", value: r });
            } catch (err: any) {
              console.error(
                `[Page ${pageId}] Sequential failed:`,
                err?.message,
              );
              push("DEVELOPER_FIX", {
                stepId: `page-${pageId}`,
                message: `⚠ ${pageLabel} page failed`,
              });
              pageResults.push({ status: "rejected", reason: err });
            }
          }
          // Footer — always last for DeepSeek
          try {
            const footerR = await silentStream(
              getFooterPrompt(prompt, designTokens, false, architect),
              "Generate the footer and closing scripts.",
              budgets.footer,
              DEVELOPER_MODEL,
              clientSignal,
              callTimeout,
            );
            push("DEVELOPER_FIX", {
              stepId: "page-footer",
              message: "✓ Footer & scripts complete",
            });
            pageResults.push({ status: "fulfilled", value: footerR });
          } catch (err: any) {
            console.error("[Page footer] Sequential failed:", err?.message);
            pageResults.push({ status: "rejected", reason: err });
          }
        } else {
          // ── Claude / fast models: PARALLEL generation ──
          const parallelPageCalls = architect.pages.map((pageId, index) => {
            const pageLabel = architect.pageLabels[index];
            const heroUrl = pageId === "home" ? heroImageUrl : undefined;
            return stagger(index)
              .then(() =>
                silentStream(
                  getPagePrompt(
                    pageId,
                    pageLabel,
                    prompt,
                    designTokens,
                    heroUrl,
                    architect,
                    uiSpec,
                    contentBrief,
                  ),
                  `Generate the complete ${pageLabel} page section.`,
                  budgets.page,
                  DEVELOPER_MODEL,
                  clientSignal,
                  callTimeout,
                ),
              )
              .then((r) => {
                pushProgressiveHtml(
                  pageId,
                  validatePageSection(r.content, pageId),
                );
                push("DEVELOPER_FIX", {
                  stepId: `page-${pageId}`,
                  message: `✓ ${pageLabel} page complete`,
                });
                return r;
              });
          });
          // Footer runs in parallel at the end index
          parallelPageCalls.push(
            stagger(architect.pages.length)
              .then(() =>
                silentStream(
                  getFooterPrompt(prompt, designTokens, false, architect),
                  "Generate the footer and closing scripts.",
                  budgets.footer,
                  DEVELOPER_MODEL,
                  clientSignal,
                  callTimeout,
                ),
              )
              .then((r) => {
                push("DEVELOPER_FIX", {
                  stepId: "page-footer",
                  message: "✓ Footer & scripts complete",
                });
                return r;
              }),
          );
          pageResults = await Promise.allSettled(parallelPageCalls);
        }

        // Log results for debugging
        const pageLabelsForLog = isSinglePage
          ? ["home", "bottom", "footer"]
          : [...architect.pages, "footer"];
        pageResults.forEach((r, i) => {
          if (r.status === "fulfilled") {
            console.log(
              `[Page ${pageLabelsForLog[i] ?? i}] ✓ ${r.value.content.length} chars, ${r.value.outputTokens} tokens`,
            );
          } else {
            console.error(
              `[Page ${pageLabelsForLog[i] ?? i}] ✗ FAILED:`,
              r.reason?.message ?? r.reason,
            );
          }
        });

        // Fallback placeholder for failed pages
        const fallback = (pageId: string) => ({
          content: `<section id="page-${pageId}" class="page"><div class="min-h-screen flex items-center justify-center py-40"><div class="text-center"><h2 class="font-display text-4xl font-bold mb-4 opacity-50">Content unavailable</h2><p class="text-white/40">This page failed to generate. Try regenerating.</p></div></div></section>`,
          outputTokens: 0,
        });

        // Extract page HTML results — dynamic, based on architect.pages
        const footerResultIndex = isSinglePage ? 2 : architect.pages.length;
        const footerResult = pageResults[footerResultIndex];
        const { content: footerContent, outputTokens: footerTokens } =
          footerResult?.status === "fulfilled"
            ? footerResult.value
            : { content: "", outputTokens: 0 };

        if (!footerContent || footerContent.length < 200) {
          console.warn("[Footer] Generation failed — using fallback footer");
        }

        // Build validated page HTML array
        const pagesToAssemble = isSinglePage
          ? ["home", "features"] // single page uses top+bottom halves
          : architect.pages;

        const validPageHtmls = pagesToAssemble.map((pageId, i) => {
          const result = pageResults[i];
          const { content } =
            result?.status === "fulfilled" ? result.value : fallback(pageId);
          const tokens =
            result?.status === "fulfilled" ? result.value.outputTokens : 0;
          totalOutputTokens += tokens;
          return isSinglePage ? content : validatePageSection(content, pageId);
        });

        totalOutputTokens += footerTokens;

        // Clean footer
        const footerTagStart = footerContent.search(/<footer/i);
        const cleanFooter =
          footerTagStart >= 0
            ? footerContent.slice(footerTagStart)
            : FALLBACK_FOOTER;
        const seoTags = buildSeoTags(brandName, prompt, heroImageUrl);

        const postProcess = (html: string): string => {
          const isLightTheme = html.includes('data-theme="light"');
          const menuBg = isLightTheme ? "#ffffff" : "#0f172a";

          return (
            html
              // SEO — inject meta tags before </head>
              .replace("</head>", `  ${seoTags}\n</head>`)
              // Fix 1 — mobile menu: remove "display: none" from inline styles
              .replace(/style="([^"]*?);\s*display:\s*none\s*"/g, 'style="$1"')
              .replace(/style="display:\s*none\s*;?\s*([^"]*)"/g, 'style="$1"')
              // Fix 2 — marquee items: ensure they don't wrap on mobile
              .replace(
                /class="flex animate-marquee/g,
                'class="flex animate-marquee whitespace-nowrap',
              )
              .replace(/<div class="flex items-center gap-\d+ pr-\d+">/g, (m) =>
                m.replace(
                  '<div class="flex',
                  '<div class="flex flex-shrink-0 flex-nowrap',
                ),
              )
              // Fix 3 — remove external texture URLs that block rendering
              .replace(/url\(["']https?:\/\/[^"')]+["']\)/g, "none")
              // Fix 4 — close any unclosed tag right before <main>
              .replace(/<[a-z][^>]*\n<main>/gi, "\n<main>")
              .replace(/class="[^"]*\n<main>/g, 'class="">\n</nav>\n<main>')
              // Fix 5 — mobile menu: force solid background + isolation
              // Targets style=" on the same line as x-show="open" and fixed
              // Simple single-line replace — no loops, no walking, no hangs
              .replace(
                /(<div[^>\n]*x-show="open"[^>\n]*fixed[^>\n]*)style="[^"]*"/g,
                `$1style="background:${menuBg};isolation:isolate;backdrop-filter:none"`,
              )
              .replace(
                /(<div[^>\n]*fixed[^>\n]*x-show="open"[^>\n]*)style="[^"]*"/g,
                `$1style="background:${menuBg};isolation:isolate;backdrop-filter:none"`,
              )
            // Fix 6 — single page: remove .page class and show the section
            // In multipage, .page { display:none } hides everything until showPage() runs
            // In single page, there's no routing so content must always be visible
          );
        };

        const pageParts = validPageHtmls.map((html) => "\n" + html);
        const htmlOutput = postProcess(
          [
            shellBase,
            "\n<main>",
            ...pageParts,
            "\n</main>",
            "\n" + cleanFooter,
          ].join(""),
        );

        // For single page — remove .page class so content is always visible
        // In multipage .page { display:none } hides everything until showPage() runs
        // In single page there's no routing so content must always be visible
        const finalHtml = isSinglePage
          ? htmlOutput
              .replace(
                /(<section[^>]*)\bclass="([^"]*\b)page\b([^"]*)"/g,
                '$1class="$2$3"',
              )
              .replace(/(<section[^>]*)class="page"/g, '$1class=""')
          : htmlOutput;

        // Quality check log
        const pageCount = (finalHtml.match(/id="page-/g) || []).length;
        const hasFooter = htmlOutput.includes("<footer");
        const hasRouting = htmlOutput.includes("showPage");
        const hasClosingTag = htmlOutput.toLowerCase().includes("</html>");
        console.log(
          `[Assembly] pages:${pageCount} footer:${hasFooter} routing:${hasRouting} </html>:${hasClosingTag} length:${htmlOutput.length} totalTokens:${totalOutputTokens}`,
        );

        totalCreditsToDeduct = calculateCredits(
          totalOutputTokens,
          DEVELOPER_MODEL,
        );

        push("DEVELOPER_DONE", {
          message: "All pages assembled! Sending preview...",
        });

        push("HTML_PREVIEW", {
          html: finalHtml,
          brandName,
          message: "Preview ready!",
        });

        push("QA_START", { message: "Running quality checks..." });
        push("QA_REPORT", {
          score: 95,
          passed: true,
          issueCount: 0,
          message: "Quality check passed!",
        });

        push("COMPLETE", {
          message: "Your website is ready!",
          html: finalHtml,
          brandName,
          modelUsed: DEVELOPER_MODEL,
          creditsUsed: totalCreditsToDeduct,
        });

        if (clientSignal.aborted) {
          console.log(
            "[Credits] Client disconnected — skipping credit deduction",
          );
        } else {
          await deductCredits(userId, totalCreditsToDeduct);
          console.log(
            `[Credits] Deducted ${totalCreditsToDeduct} credits for ${DEVELOPER_MODEL} (${totalOutputTokens} tokens)`,
          );
        }
      } catch (err: any) {
        if (err.name === "AbortError" || clientSignal.aborted) {
          {
            console.log(
              "[Pipeline] Connection dropped or aborted — generation was running",
            );
            // Still try to deduct credits if we generated content
            if (!creditsDone && totalOutputTokens > 0) {
              try {
                creditsDone = true;
                await deductCredits(userId, totalCreditsToDeduct);
                console.log(
                  `[Credits] Late deduction: ${totalCreditsToDeduct} credits`,
                );
              } catch (e) {
                console.error("[Credits] Late deduction failed:", e);
              }
            }
          }
          return;
        }
        console.error("Deep dive pipeline error:", err);
        push("ERROR", {
          message: "Something went wrong during generation. Please try again.",
        });
      } finally {
        clearInterval(keepalive);

        closeStream();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
